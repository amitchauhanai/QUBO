import numpy as np
from typing import Optional


class DensityMatrixSimulator:
    """A minimal density-matrix simulator for small qubit counts.

    Note: This is intentionally simple and not optimized for many qubits.
    """

    def __init__(self, circuit, dtype=complex):
        self.circuit = circuit
        self.num_qubits = int(circuit.num_qubits)
        self.dim = 2 ** self.num_qubits
        self.rho = np.zeros((self.dim, self.dim), dtype=dtype)
        self.rho[0, 0] = 1.0

    def _kron(self, mats):
        out = mats[0]
        for m in mats[1:]:
            out = np.kron(out, m)
        return out

    def apply_unitary(self, U, targets):
        # build full operator
        ops = []
        tq = set(targets)
        for i in range(self.num_qubits):
            if i in tq:
                ops.append(U)
            else:
                ops.append(np.eye(2, dtype=U.dtype))
        full = self._kron(ops)
        self.rho = full @ self.rho @ full.conj().T

    def apply_kraus(self, kraus_ops, targets):
        # This applies a single-qubit Kraus to each target individually (not multi-qubit correlated)
        for t in targets:
            new_rho = np.zeros_like(self.rho)
            for K in kraus_ops:
                # build full operator with K at position t
                ops = []
                for i in range(self.num_qubits):
                    if i == t:
                        ops.append(K)
                    else:
                        ops.append(np.eye(2, dtype=K.dtype))
                full = self._kron(ops)
                new_rho += full @ self.rho @ full.conj().T
            self.rho = new_rho

    def measure_probabilities(self):
        probs = np.real(np.diag(self.rho))
        labels = [format(i, f'0{self.num_qubits}b') for i in range(len(probs))]
        return dict(zip(labels, probs.tolist()))


# Kraus helpers

def amplitude_damping_kraus(p):
    K0 = np.array([[1, 0], [0, np.sqrt(1 - p)]], dtype=complex)
    K1 = np.array([[0, np.sqrt(p)], [0, 0]], dtype=complex)
    return [K0, K1]


def depolarizing_kraus(p):
    # single-qubit depolarizing channel Kraus set
    I = np.eye(2, dtype=complex)
    X = np.array([[0, 1], [1, 0]], dtype=complex)
    Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    Z = np.array([[1, 0], [0, -1]], dtype=complex)
    K0 = np.sqrt(1 - p) * I
    K1 = np.sqrt(p / 3.0) * X
    K2 = np.sqrt(p / 3.0) * Y
    K3 = np.sqrt(p / 3.0) * Z
    return [K0, K1, K2, K3]
