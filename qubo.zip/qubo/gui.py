import sys
import io
import traceback
from typing import Optional

from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QFileDialog,
    QLabel,
    QListWidget,
    QPlainTextEdit,
    QSplitter,
    QTabWidget,
    QSpinBox,
    QComboBox,
    QCheckBox,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from qubo.simulator import StatevectorSimulator
from qubo.visualizer import plot_statevector
from qubo import noise as qubo_noise
import json
import subprocess
import sys
from pathlib import Path

# Dark purple theme
STYLE = """
QWidget { background-color: #120022; color: #e6d6ff; }
QPlainTextEdit { background-color: #0f001b; color: #e6d6ff; border: 1px solid #2b003b; }
QLabel { color: #e6d6ff; }
QListWidget { background-color: #160028; color: #e6d6ff; border: 1px solid #2b003b; }
QPushButton { background-color: #220033; color: #e6d6ff; border: 1px solid #3a0050; padding: 6px; }
QPushButton:hover { background-color: #3a0050; }
QTabWidget::pane { background: #14001f; }
QTabBar::tab { background: #1a0028; color: #d9c8ff; padding: 6px; }
QTabBar::tab:selected { background: #2b0040; }
QSplitter { background: #120022; }
"""


class CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFont(QFont('Consolas', 11))
        self.setPlainText(
            """from qubo.circuit import QuantumCircuit

qc = QuantumCircuit(2)
qc.add_gate('H', targets=[0])
qc.add_gate('X', targets=[1])
qc.add_gate('M', targets=[0])
"""
        )


class OutputPanel(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont('Consolas', 10))

    def write(self, text: str):
        self.appendPlainText(text)


class MatplotlibCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=3, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        super().__init__(fig)
        self.setParent(parent)
        self.ax = fig.add_subplot(111)

    def plot_state(self, state):
        self.ax.clear()
        n = int((len(state)).bit_length() - 1)
        probs = (abs(state) ** 2).real
        labels = [format(i, f'0{n}b') for i in range(len(state))]
        self.ax.bar(range(len(probs)), probs, color='#b892ff')
        self.ax.set_xticks(range(len(probs)))
        self.ax.set_xticklabels(labels, rotation=90, fontsize=8)
        self.ax.set_ylabel('Probability')
        self.figure.tight_layout()
        self.draw()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('qubo — Quantum IDE')
        self.resize(1100, 700)

        central = QSplitter(Qt.Horizontal)

        # Left: gates + preview
        left = QWidget()
        left_layout = QVBoxLayout()
        left_layout.setContentsMargins(6, 6, 6, 6)
        left_layout.addWidget(QLabel('Gates'))
        self.gate_list = QListWidget()
        for g in ['H', 'X', 'CNOT', 'RZ', 'Measure']:
            self.gate_list.addItem(g)
        left_layout.addWidget(self.gate_list)
        left_layout.addWidget(QLabel('Circuit preview'))
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        left_layout.addWidget(self.preview)

        # Extras panel: show advanced modules / phase-2 tools
        left_layout.addWidget(QLabel('Extras'))
        self.extras_list = QListWidget()
        for item in [
            'Density backend',
            'JAX backend',
            'GPU (CUDA)',
            'REST service (FastAPI)',
            'Tensor-network backend',
            'Transpiler/optimizer',
            'VS Code extension / widgets',
        ]:
            self.extras_list.addItem(item)
        left_layout.addWidget(self.extras_list)

        # Extras control buttons
        extras_ctrl = QHBoxLayout()
        self.extras_inspect = QPushButton('Inspect')
        self.extras_toggle = QPushButton('Enable/Toggle')
        self.extras_install = QPushButton('Install Help')
        self.extras_run_install = QPushButton('Run Install')
        self.auto_select_chk = QCheckBox('Auto-select backend')
        extras_ctrl.addWidget(self.extras_inspect)
        extras_ctrl.addWidget(self.extras_toggle)
        extras_ctrl.addWidget(self.extras_install)
        extras_ctrl.addWidget(self.extras_run_install)
        extras_ctrl.addWidget(self.auto_select_chk)
        left_layout.addLayout(extras_ctrl)
        left.setLayout(left_layout)

        central.addWidget(left)

        # Right: editor + tabs
        right = QWidget()
        right_layout = QVBoxLayout()
        toolbar = QHBoxLayout()
        self.open_btn = QPushButton('Open')
        self.save_btn = QPushButton('Save')
        self.run_btn = QPushButton('Run')
        toolbar.addWidget(self.open_btn)
        toolbar.addWidget(self.save_btn)
        toolbar.addStretch()
        toolbar.addWidget(QLabel('Shots:'))
        self.shots_spin = QSpinBox()
        self.shots_spin.setRange(1, 100000)
        self.shots_spin.setValue(1024)
        toolbar.addWidget(self.shots_spin)
        toolbar.addWidget(QLabel('Noise:'))
        self.noise_combo = QComboBox()
        self.noise_combo.addItems(['None', 'Bit-flip', 'Phase-flip', 'Depolarizing', 'Amplitude Damping'])
        toolbar.addWidget(self.noise_combo)
        toolbar.addWidget(self.run_btn)
        right_layout.addLayout(toolbar)

        self.editor = CodeEditor()
        right_layout.addWidget(self.editor, stretch=3)

        self.tabs = QTabWidget()
        self.output = OutputPanel()
        self.sim_tab = QWidget()
        sim_layout = QVBoxLayout()
        self.sim_output = OutputPanel()
        sim_layout.addWidget(QLabel('Simulator Output'))
        sim_layout.addWidget(self.sim_output)
        self.sim_tab.setLayout(sim_layout)

        self.vis_tab = QWidget()
        vis_layout = QVBoxLayout()
        self.canvas = MatplotlibCanvas()
        vis_layout.addWidget(self.canvas)
        self.vis_tab.setLayout(vis_layout)

        self.noise_tab = QWidget()
        noise_layout = QVBoxLayout()
        noise_layout.addWidget(QLabel('Noise preview'))
        self.noise_info = OutputPanel()
        noise_layout.addWidget(self.noise_info)
        self.noise_tab.setLayout(noise_layout)

        self.tabs.addTab(self.output, 'Output')
        self.tabs.addTab(self.sim_tab, 'Simulator')
        self.tabs.addTab(self.vis_tab, 'Visualizer')
        self.tabs.addTab(self.noise_tab, 'Noise')

        right_layout.addWidget(self.tabs, stretch=2)
        right.setLayout(right_layout)

        central.addWidget(right)
        central.setStretchFactor(0, 1)
        central.setStretchFactor(1, 3)

        self.setCentralWidget(central)

        # connections
        self.open_btn.clicked.connect(self.open_file)
        self.save_btn.clicked.connect(self.save_file)
        self.run_btn.clicked.connect(self.run_all)
    self.gate_list.itemDoubleClicked.connect(self.insert_gate)
        self.extras_inspect.clicked.connect(self.inspect_extras)
        self.extras_toggle.clicked.connect(self.toggle_extra)
        self.extras_install.clicked.connect(self.install_help)
        self.extras_run_install.clicked.connect(self.run_install)
        self.auto_select_chk.stateChanged.connect(self._on_auto_select_changed)

		# config path
		self._config_path = Path.cwd() / '.qubo_config.json'
		self._enabled_extras = set()
		self._auto_select = False
		self.load_config()

        self.setStyleSheet(STYLE)

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Open Python File', '', 'Python Files (*.py)')
        if not path:
            return
        try:
            with open(path, 'r', encoding='utf-8') as f:
                self.editor.setPlainText(f.read())
        except Exception as e:
            self.output.write('Error opening file: ' + str(e))

    def save_file(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Save Python File', '', 'Python Files (*.py)')
        if not path:
            return
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(self.editor.toPlainText())
            self.output.write(f'Saved: {path}')
        except Exception as e:
            self.output.write('Error saving file: ' + str(e))

    def insert_gate(self, item):
        g = item.text()
        cursor = self.editor.textCursor()
        if g == 'CNOT':
            cursor.insertText("qc.add_gate('CNOT', targets=[0,1])\n")
        elif g == 'RZ':
            cursor.insertText("qc.add_gate('RZ', targets=[0], params=[3.1415])\n")
        else:
            cursor.insertText(f"qc.add_gate('{g}', targets=[0])\n")

    def run_all(self):
        code = self.editor.toPlainText()
        buf_out = io.StringIO()
        buf_err = io.StringIO()
        try:
            # execute user code in isolated namespace
            ns = {}
            exec(code, ns)
            if 'qc' in ns:
                # prepare noise hook
                noise_choice = self.noise_combo.currentText()
                noise_hook = None
                if noise_choice != 'None':
                    mapping = {
                        'Bit-flip': (qubo_noise.bit_flip, 0.01),
                        'Phase-flip': (qubo_noise.phase_flip, 0.01),
                        'Depolarizing': (qubo_noise.depolarizing, 0.01),
                        'Amplitude Damping': (qubo_noise.amplitude_damping, 0.01),
                    }
                    func, p = mapping.get(noise_choice, (None, 0.0))
                    if func:
                        def _hook(state, gate, _f=func, _p=p):
                            for t in gate.targets:
                                state = _f(state, _p, t)
                            return state
                        noise_hook = _hook

                shots = int(self.shots_spin.value())

                # select backend based on enabled extras
                backend_choice = 'numpy'
                if hasattr(self, '_enabled_extras') and 'Density backend' in self._enabled_extras:
                    # use density matrix simulator when enabled
                    from qubo.density import DensityMatrixSimulator
                    dsim = DensityMatrixSimulator(ns['qc'])
                    # apply each gate (best-effort mapping)
                    for gate in ns['qc'].gates:
                        name = gate.name
                        if name in ('H', 'X', 'RX', 'RY', 'RZ'):
                            # build single-qubit unitary where possible
                            import numpy as _np
                            if name == 'H':
                                U = (1/_np.sqrt(2))*_np.array([[1,1],[1,-1]], dtype=complex)
                            elif name == 'X':
                                U = _np.array([[0,1],[1,0]], dtype=complex)
                            elif name == 'RX':
                                theta = gate.params[0] if gate.params else 0.0
                                U = _np.array([[_np.cos(theta/2), -1j*_np.sin(theta/2)],[-1j*_np.sin(theta/2), _np.cos(theta/2)]], dtype=complex)
                            elif name == 'RY':
                                theta = gate.params[0] if gate.params else 0.0
                                U = _np.array([[_np.cos(theta/2), -_np.sin(theta/2)],[_np.sin(theta/2), _np.cos(theta/2)]], dtype=complex)
                            elif name == 'RZ':
                                theta = gate.params[0] if gate.params else 0.0
                                U = _np.array([[_np.exp(-0.5j*theta),0],[0,_np.exp(0.5j*theta)]], dtype=complex)
                            dsim.apply_unitary(U, gate.targets)
                        elif name == 'CNOT':
                            # no direct multi-qubit unitary helper here; fall back to naive mapping via Kraus-free approach
                            # for now treat as ideal unitary by constructing full operator
                            import numpy as _np
                            control, target = gate.targets[0], gate.targets[1]
                            # build full CNOT
                            I = _np.eye(2, dtype=complex)
                            X = _np.array([[0,1],[1,0]], dtype=complex)
                            proj0 = _np.array([[1,0],[0,0]], dtype=complex)
                            proj1 = _np.array([[0,0],[0,1]], dtype=complex)
                            ops = []
                            for i in range(ns['qc'].num_qubits):
                                if i == control:
                                    ops.append(proj0)
                                else:
                                    ops.append(I)
                            full0 = _np.kron(ops[0], ops[1]) if len(ops)==2 else ops[0]
                            # simplify: rebuild full operator using computational basis (slow)
                            dim = 2**ns['qc'].num_qubits
                            C = _np.zeros((dim, dim), dtype=complex)
                            for i in range(dim):
                                b = list(reversed([int(x) for x in format(i, f'0{ns["qc"].num_qubits}b')]))
                                if b[control] == 0:
                                    C[i, i] = 1
                                else:
                                    # flip target bit
                                    j = i ^ (1 << target)
                                    C[j, i] = 1
                            dsim.rho = C @ dsim.rho @ C.conj().T
                    # after applying gates, show probabilities
                    probs = dsim.measure_probabilities()
                    self.sim_output.setPlainText(str(probs))
                    # visualize
                    import numpy as _np
                    approx = [probs.get(format(i, f'0{ns["qc"].num_qubits}b'), 0) for i in range(2 ** ns['qc'].num_qubits)]
                    self.canvas.plot_state(_np.array(approx))
                    self.tabs.setCurrentIndex(1)
                    return
                elif hasattr(self, '_enabled_extras') and 'JAX backend' in self._enabled_extras:
                    backend_choice = 'jax'

                # fall back to StatevectorSimulator (numpy) or jax if enabled
                if backend_choice == 'jax':
                    sim = StatevectorSimulator(ns['qc'], noise_hook=noise_hook, backend='jax')
                else:
                    sim = StatevectorSimulator(ns['qc'], noise_hook=noise_hook, backend='numpy')
                res = sim.run(shots=shots)
                if isinstance(res, dict):
                    buf_out.write(str(res) + '\n')
                    self.sim_output.setPlainText(str(res))
                    # visualize distribution by expanding counts to probabilities
                    # build a full statevector approximation
                    total = sum(res.values())
                    approx = [res.get(format(i, f'0{ns["qc"].num_qubits}b'), 0) / total for i in range(2 ** ns['qc'].num_qubits)]
                    import numpy as _np
                    self.canvas.plot_state(_np.array(approx))
                else:
                    # full statevector
                    import numpy as _np
                    self.canvas.plot_state(res)
                    buf_out.write('Statevector length: %d\n' % len(res))
                self.tabs.setCurrentIndex(1)
            else:
                buf_out.write("No 'qc' QuantumCircuit found in code.\n")
        except Exception:
            buf_err.write(traceback.format_exc())

        out_text = buf_out.getvalue()
        err_text = buf_err.getvalue()
        if out_text:
            self.output.write(out_text)
        if err_text:
            self.output.write(err_text)

    def inspect_extras(self):
        # Check availability of optional tools and report to output panel
        items = [self.extras_list.item(i).text() for i in range(self.extras_list.count())]
        report = []
        for it in items:
            if it == 'JAX backend':
                try:
                    import importlib
                    mod = importlib.import_module('qubo.backends.jax_backend')
                    ok = getattr(mod, 'is_available', lambda: False)()
                report.append(f"JAX backend: {'available' if ok else 'not available'}")
            except Exception:
                report.append('JAX backend: not installed')
            elif it == 'Density backend':
                try:
                    import qubo.density as _d
                    report.append('Density backend: available')
                except Exception:
                report.append('Density backend: not installed')
            elif it == 'GPU (CUDA)':
                try:
                    import jax
                    from jax.lib import xla_bridge
                    backend = xla_bridge.get_backend().platform
                    report.append(f'GPU: jax platform={backend}')
                except Exception:
                report.append('GPU: not available (no jax/cuda)')
            elif it == 'REST service (FastAPI)':
                try:
                    import fastapi
                    report.append('FastAPI: installed')
                except Exception:
                report.append('FastAPI: not installed')
            elif it == 'Tensor-network backend':
                # heuristic: check for 'cotengra' or 'opt_einsum'
                try:
                    import opt_einsum
                    report.append('Tensor backends: opt_einsum available')
                except Exception:
                report.append('Tensor backends: not available')
            elif it == 'Transpiler/optimizer':
                # check for a local transpiler module
                import importlib
                try:
                    importlib.import_module('qubo.transpiler')
                    report.append('Transpiler: present')
                except Exception:
                report.append('Transpiler: not present')
            elif it == 'VS Code extension / widgets':
                report.append('VS Code extension: not bundled (see docs)')

        self.output.clear()
        for r in report:
            self.output.write(r)

    def toggle_extra(self):
        # Toggle a simple in-memory enabled flag for the selected extra
        sel = self.extras_list.currentItem()
        if not sel:
            self.output.write('Select an extra to toggle')
            return
        name = sel.text()
        if not hasattr(self, '_enabled_extras'):
            self._enabled_extras = set()
        if name in self._enabled_extras:
            self._enabled_extras.remove(name)
            self.output.write(f'Disabled: {name}')
        else:
            self._enabled_extras.add(name)
            self.output.write(f'Enabled: {name}')
        # persist
        self.save_config()
        # if auto-select enabled, write a note
        if getattr(self, '_auto_select', False):
            self.output.write('Auto-select is enabled; run will choose available backend')

    def install_help(self):
        # Print pip install suggestions for the selected extra
        sel = self.extras_list.currentItem()
        if not sel:
            self.output.write('Select an extra to get install help')
            return
        name = sel.text()
        cmds = []
        if name == 'JAX backend':
            cmds = [
                '# JAX CPU (for testing):',
                'pip install --upgrade pip',
                'pip install jax jaxlib',
                '# For CUDA builds see jax documentation for the correct jaxlib wheel',
            ]
        elif name == 'Density backend':
            cmds = ['# density backend uses numpy (already included)', 'pip install numpy']
        elif name == 'GPU (CUDA)':
            cmds = ['# GPU support requires jax with CUDA-enabled jaxlib; see jax docs for wheel selection']
        elif name == 'REST service (FastAPI)':
            cmds = ['pip install fastapi uvicorn']
        elif name == 'Tensor-network backend':
            cmds = ['pip install opt_einsum cotengra']
        elif name == 'Transpiler/optimizer':
            cmds = ['# No package yet; see docs.']
        else:
            cmds = ['# No install help available for this item']

        self.output.write(f'Install suggestions for: {name}')
        for c in cmds:
            self.output.write(c)

    def run_install(self):
        # Execute pip install for the selected extra using the current Python executable
        sel = self.extras_list.currentItem()
        if not sel:
            self.output.write('Select an extra to install')
            return
        name = sel.text()
        if name == 'JAX backend':
            pkgs = ['jax', 'jaxlib']
        elif name == 'REST service (FastAPI)':
            pkgs = ['fastapi', 'uvicorn']
        elif name == 'Tensor-network backend':
            pkgs = ['opt_einsum', 'cotengra']
        else:
            self.output.write(f'No automated install rule for: {name}')
            return

        cmd = [sys.executable, '-m', 'pip', 'install'] + pkgs
        self.output.write(f'Running: {cmd}')
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
            self.output.write(proc.stdout or '(no stdout)')
            if proc.stderr:
                self.output.write('ERROR:')
                self.output.write(proc.stderr)
            # after install attempt re-run inspect
            self.inspect_extras()
        except Exception as e:
            self.output.write('Install failed: ' + str(e))

    def _on_auto_select_changed(self, state):
        self._auto_select = bool(state)
        self.save_config()

    def load_config(self):
        try:
            if self._config_path.exists():
                with open(self._config_path, 'r', encoding='utf-8') as f:
                    cfg = json.load(f)
                    self._enabled_extras = set(cfg.get('enabled_extras', []))
                    self._auto_select = bool(cfg.get('auto_select', False))
                    self.auto_select_chk.setChecked(self._auto_select)
                    if self._enabled_extras:
                        self.output.write('Loaded enabled extras from config: ' + ', '.join(self._enabled_extras))
        except Exception:
            pass

    def save_config(self):
        try:
            with open(self._config_path, 'w', encoding='utf-8') as f:
                json.dump({'enabled_extras': list(self._enabled_extras), 'auto_select': self._auto_select}, f, indent=2)
        except Exception:
            pass


def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
import sys
import traceback
import io
from types import SimpleNamespace
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QFileDialog,
    QLabel,
    QListWidget,
    QPlainTextEdit,
    QSplitter,
    QTabWidget,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

# Dark purple theme stylesheet (deep background, light purple text)
STYLE = """
QWidget { background-color: #120022; color: #e6d6ff; }
QPlainTextEdit { background-color: #0f001b; color: #e6d6ff; border: 1px solid #2b003b; }
QLabel { color: #e6d6ff; }
QListWidget { background-color: #160028; color: #e6d6ff; border: 1px solid #2b003b; }
QPushButton { background-color: #220033; color: #e6d6ff; border: 1px solid #3a0050; padding: 6px; }
QPushButton:hover { background-color: #3a0050; }
QTabWidget::pane { background: #14001f; }
QTabBar::tab { background: #1a0028; color: #d9c8ff; padding: 6px; }
QTabBar::tab:selected { background: #2b0040; }
QSplitter { background: #120022; }
QScrollBar:vertical { background: #100018; }
QToolTip { background-color: #2b0040; color: #f6edff; }
"""
# Lightweight code editor
class CodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFont(QFont('Consolas', 11))
        # sample starter content
        self.setPlainText(
            """from qubo.circuit import QuantumCircuit

qc = QuantumCircuit(2)
qc.add_gate('H', targets=[0])
qc.add_gate('X', targets=[1])
print('Circuit:', qc)
"""
        )


class OutputPanel(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont('Consolas', 10))

    def write(self, text: str):
        self.appendPlainText(text)

    def clear(self):
        super().clear()


class GatePalette(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout()
        layout.setContentsMargins(4, 4, 4, 4)
        layout.addWidget(QLabel("Gates"))
        self.list = QListWidget()
        for g in ["H", "X", "Y", "Z", "CNOT", "Measure"]:
            self.list.addItem(g)
        layout.addWidget(self.list)
        self.setLayout(layout)


class CircuitDiagram(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Circuit Diagram (preview)"))
        self.preview = QLabel("<i>Visual preview will appear here.</i>")
        self.preview.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        layout.addWidget(self.preview)
        self.setLayout(layout)

    def update_from_code(self, code: str):
        # Very small heuristic preview: show lines that mention add_gate
        lines = [ln.strip() for ln in code.splitlines() if "add_gate" in ln or "QuantumCircuit" in ln]
        if not lines:
            self.preview.setText("<i>No gates detected in code.</i>")
        else:
            self.preview.setText("\n".join(lines))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('qubo — Quantum IDE')
        self.resize(1000, 700)

        # Central splitter: sidebar | editor+tabs
        central = QSplitter(Qt.Horizontal)

        # Left sidebar (gate palette + circuit preview)
        left = QWidget()
        left_layout = QVBoxLayout()
        left_layout.setContentsMargins(4, 4, 4, 4)
        self.gate_palette = GatePalette()
        left_layout.addWidget(self.gate_palette)
        self.circuit_diagram = CircuitDiagram()
        left_layout.addWidget(self.circuit_diagram)
        left.setLayout(left_layout)

        central.addWidget(left)

        # Right area: editor on top, tabs bottom
        right = QWidget()
        right_layout = QVBoxLayout()
        right_layout.setContentsMargins(4, 4, 4, 4)

        # Toolbar buttons
        toolbar = QHBoxLayout()
        self.open_btn = QPushButton('Open')
        self.save_btn = QPushButton('Save')
        self.run_btn = QPushButton('Run')
        toolbar.addWidget(self.open_btn)
        toolbar.addWidget(self.save_btn)
        toolbar.addStretch(1)
        toolbar.addWidget(self.run_btn)
        right_layout.addLayout(toolbar)

        # Editor
        self.editor = CodeEditor()
        right_layout.addWidget(self.editor, stretch=3)

        # Tabs: Output, Simulator, Visualizer, Noise
        self.tabs = QTabWidget()
        self.output_panel = OutputPanel()
        self.sim_tab = QWidget()
        sim_layout = QVBoxLayout()
        sim_layout.addWidget(QLabel('Simulator controls (placeholder)'))
        self.sim_tab.setLayout(sim_layout)

        self.vis_tab = QWidget()
        vis_layout = QVBoxLayout()
        vis_layout.addWidget(QLabel('Visualizer (placeholder)'))
        self.vis_tab.setLayout(vis_layout)

        self.noise_tab = QWidget()
        noise_layout = QVBoxLayout()
        noise_layout.addWidget(QLabel('Noise models (placeholder)'))
        self.noise_tab.setLayout(noise_layout)

        self.tabs.addTab(self.output_panel, 'Output')
        self.tabs.addTab(self.sim_tab, 'Simulator')
        self.tabs.addTab(self.vis_tab, 'Visualizer')
        self.tabs.addTab(self.noise_tab, 'Noise')

        right_layout.addWidget(self.tabs, stretch=2)
        right.setLayout(right_layout)

        central.addWidget(right)
        central.setStretchFactor(0, 1)
        central.setStretchFactor(1, 3)

        self.setCentralWidget(central)

        # Connections
        self.open_btn.clicked.connect(self.open_file)
        self.save_btn.clicked.connect(self.save_file)
        self.run_btn.clicked.connect(self.run_code)
        self.editor.textChanged.connect(self.on_code_changed)

        # quick connect double-click gate -> insert into code
        self.gate_palette.list.itemDoubleClicked.connect(self.insert_gate_into_code)

    def on_code_changed(self):
        code = self.editor.toPlainText()
        self.circuit_diagram.update_from_code(code)

    def insert_gate_into_code(self, item):
        gate = item.text()
        cursor = self.editor.textCursor()
        snippet = f"qc.add_gate('{gate}', targets=[0])\n"
        cursor.insertText(snippet)

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Open Python File', '', 'Python Files (*.py)')
        if not path:
            return
        try:
            with open(path, 'r', encoding='utf-8') as f:
                self.editor.setPlainText(f.read())
        except Exception as e:
            self.output_panel.write('Error opening file: ' + str(e))

    def save_file(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Save Python File', '', 'Python Files (*.py)')
        if not path:
            return
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(self.editor.toPlainText())
            self.output_panel.write(f'Saved: {path}')
        except Exception as e:
            self.output_panel.write('Error saving file: ' + str(e))

    def run_code(self):
        code = self.editor.toPlainText()
        # Capture stdout/stderr
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        buf_out = io.StringIO()
        buf_err = io.StringIO()
        sys.stdout = buf_out
        sys.stderr = buf_err

        # Prepare safe-ish namespace
        namespace = {"__name__": "__main__"}
        # Provide quick access to package
        try:
            # Execute
            exec(code, namespace)
        except Exception:
            tb = traceback.format_exc()
            buf_err.write(tb)
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

        out_text = buf_out.getvalue()
        err_text = buf_err.getvalue()
        if out_text:
            self.output_panel.write(out_text)
        if err_text:
            self.output_panel.write(err_text)
        # Switch to Output tab
        self.tabs.setCurrentIndex(0)


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLE)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

from PyQt5 import QtWidgets, QtGui, QtCore

class WindowControls(QtWidgets.QWidget):
    class MainWindow(QtWidgets.QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("Qubo Quantum IDE")
            self.setStyleSheet("background-color: #181a1b; color: #d4d4d4;")
            self.resize(1300, 800)

            # Central widget layout
            central = QtWidgets.QWidget()
            layout = QtWidgets.QHBoxLayout(central)
            layout.setContentsMargins(0,0,0,0)
            layout.setSpacing(0)

            # Sidebar
            self.sidebar = Sidebar(central)
            layout.addWidget(self.sidebar)

            # Main vertical layout (editor, circuit, output)
            main_vbox = QtWidgets.QVBoxLayout()
            main_vbox.setContentsMargins(8,8,8,8)
            main_vbox.setSpacing(8)

            # Window controls (macOS style)
            self.window_controls = WindowControls(self)
            main_vbox.addWidget(self.window_controls, alignment=QtCore.Qt.AlignRight)

            # Tabbed panel for sidebar
            self.tab_widget = QtWidgets.QStackedWidget()

            # --- Circuit Builder Panel ---
            builder_panel = QtWidgets.QWidget()
            builder_layout = QtWidgets.QVBoxLayout(builder_panel)
            self.gate_palette = GatePalette(self, self)
            builder_layout.addWidget(self.gate_palette)
            self.circuit_diagram = CircuitDiagram(self)
            builder_layout.addWidget(self.circuit_diagram)
            splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
            self.editor = CodeEditor()
            self.editor.setPlainText("""# Write your quantum circuit code here\nfrom qubo.circuit import QuantumCircuit\nfrom qubo.gates import H, X, Measure\n\nqc = QuantumCircuit(2)\nqc.add_gate(H(0))\nqc.add_gate(X(1))\nqc.add_gate(Measure(0))\n""")
            splitter.addWidget(self.editor)
            self.output = OutputPanel()
            splitter.addWidget(self.output)
            splitter.setSizes([400, 200])
            builder_layout.addWidget(splitter)
            self.tab_widget.addWidget(builder_panel)

            # --- Simulator Panel ---
            self.simulator_panel = QtWidgets.QWidget()
            sim_layout = QtWidgets.QVBoxLayout(self.simulator_panel)
            self.sim_output = OutputPanel()
            sim_layout.addWidget(QtWidgets.QLabel("Simulator Results:"))
            sim_layout.addWidget(self.sim_output)
            self.tab_widget.addWidget(self.simulator_panel)

            # --- Visualizer Panel ---
            self.visualizer_panel = QtWidgets.QWidget()
            vis_layout = QtWidgets.QVBoxLayout(self.visualizer_panel)
            self.vis_diagram = CircuitDiagram(self)
            vis_layout.addWidget(QtWidgets.QLabel("Circuit Visualizer:"))
            vis_layout.addWidget(self.vis_diagram)
            self.vis_output = OutputPanel()
            vis_layout.addWidget(self.vis_output)
            self.tab_widget.addWidget(self.visualizer_panel)

            # --- Noise Panel ---
            self.noise_panel = QtWidgets.QWidget()
            noise_layout = QtWidgets.QVBoxLayout(self.noise_panel)
            noise_layout.addWidget(QtWidgets.QLabel("Noise Controls:"))
            self.noise_select = QtWidgets.QComboBox()
            self.noise_select.addItems(["None", "Bit-flip", "Phase-flip", "Depolarizing", "Amplitude Damping"])
            noise_layout.addWidget(self.noise_select)
            self.noise_output = OutputPanel()
            noise_layout.addWidget(self.noise_output)
            self.tab_widget.addWidget(self.noise_panel)

            # --- Docs Panel ---
            self.docs_panel = QtWidgets.QWidget()
            docs_layout = QtWidgets.QVBoxLayout(self.docs_panel)
            docs_layout.addWidget(QtWidgets.QLabel("Documentation and Quickstart coming soon!"))
            self.tab_widget.addWidget(self.docs_panel)

            main_vbox.addWidget(self.tab_widget)
            layout.addLayout(main_vbox)
            self.setCentralWidget(central)

            # Sidebar tab switching
            self.sidebar.currentRowChanged.connect(self.tab_widget.setCurrentIndex)
            self.sidebar.currentRowChanged.connect(self.on_tab_changed)

            # Menu bar
            menubar = self.menuBar()
            fileMenu = menubar.addMenu("File")
            openAction = QtWidgets.QAction("Open...", self)
            openAction.triggered.connect(self.open_file)
            saveAction = QtWidgets.QAction("Save As...", self)
            saveAction.triggered.connect(self.save_file)
            fileMenu.addAction(openAction)
            fileMenu.addAction(saveAction)
            runMenu = menubar.addMenu("Run")
            runAction = QtWidgets.QAction("Run Circuit", self)
            runAction.setShortcut("F5")
            runAction.triggered.connect(self.run_circuit)
            runMenu.addAction(runAction)

            # Internal circuit for builder
            self.builder_circuit = QuantumCircuit(2)
            self.update_circuit_diagram()

        def on_tab_changed(self, idx):
            # When switching tabs, update content if needed
            if idx == 1:  # Simulator
                self.run_simulator_panel()
            elif idx == 2:  # Visualizer
                self.update_visualizer_panel()
            elif idx == 3:  # Noise
                self.update_noise_panel()

        def run_simulator_panel(self):
            # Run the circuit and show results in Simulator panel
            code = self.editor.toPlainText()
            import io, contextlib, sys, traceback
            if '' not in sys.path:
                sys.path.insert(0, '')
            local_ns = {}
            f = io.StringIO()
            try:
                with contextlib.redirect_stdout(f):
                    exec(code, {}, local_ns)
                    if 'qc' in local_ns:
                        from qubo.simulator import StatevectorSimulator
                        sim = StatevectorSimulator(local_ns['qc'])
                        result = sim.run(shots=1000)
                        print(result)
                    else:
                        print("No 'qc' QuantumCircuit found in code.")
            except Exception:
                f.write(traceback.format_exc())
            self.sim_output.setPlainText(f.getvalue())

        def update_visualizer_panel(self):
            # Show the circuit diagram and statevector bar chart
            code = self.editor.toPlainText()
            import io, contextlib, sys, traceback
            if '' not in sys.path:
                sys.path.insert(0, '')
            local_ns = {}
            f = io.StringIO()
            try:
                with contextlib.redirect_stdout(f):
                    exec(code, {}, local_ns)
                    if 'qc' in local_ns:
                        self.vis_diagram.set_circuit(local_ns['qc'])
                        from qubo.simulator import StatevectorSimulator
                        sim = StatevectorSimulator(local_ns['qc'])
                        sim.run(shots=1)
                        from qubo.visualizer import plot_statevector
                        import matplotlib.pyplot as plt
                        plot_statevector(sim.state)
                        plt.show()
                        print("Statevector visualized above.")
                    else:
                        print("No 'qc' QuantumCircuit found in code.")
            except Exception:
                f.write(traceback.format_exc())
            self.vis_output.setPlainText(f.getvalue())

        def update_noise_panel(self):
            # Apply selected noise to the circuit and show result
            code = self.editor.toPlainText()
            noise_type = self.noise_select.currentText()
            import io, contextlib, sys, traceback
            if '' not in sys.path:
                sys.path.insert(0, '')
            local_ns = {}
            f = io.StringIO()
            try:
                with contextlib.redirect_stdout(f):
                    exec(code, {}, local_ns)
                    if 'qc' in local_ns:
                        from qubo.simulator import StatevectorSimulator
                        from qubo import noise
                        sim = StatevectorSimulator(local_ns['qc'])
                        state = sim.state
                        if noise_type == "Bit-flip":
                            state = noise.bit_flip(state, 0.1, 0)
                        elif noise_type == "Phase-flip":
                            state = noise.phase_flip(state, 0.1, 0)
                        elif noise_type == "Depolarizing":
                            state = noise.depolarizing(state, 0.1, 0)
                        elif noise_type == "Amplitude Damping":
                            state = noise.amplitude_damping(state, 0.1, 0)
                        print("Noisy state (first 8 amplitudes):", state[:8])
                    else:
                        print("No 'qc' QuantumCircuit found in code.")
            except Exception:
                f.write(traceback.format_exc())
            self.noise_output.setPlainText(f.getvalue())
            qp.drawLine(margin, y, width-margin, y)
            qp.setPen(QtGui.QPen(QtCore.Qt.white, 1))
            qp.drawText(10, y+5, f"q[{i}]")
        # Draw gates
        gate_spacing = (width - 2*margin) // (len(self.circuit.gates)+1) if self.circuit.gates else 0
        for idx, gate in enumerate(self.circuit.gates):
            x = margin + (idx+1)*gate_spacing
            for t in gate.targets:
                y = margin + t*spacing
                rect = QtCore.QRectF(x-15, y-15, 30, 30)
                qp.setBrush(QtGui.QColor('#007acc'))
                qp.setPen(QtGui.QPen(QtCore.Qt.black, 2))
                qp.drawEllipse(rect)
                qp.setPen(QtGui.QPen(QtCore.Qt.white, 2))
                qp.drawText(x-10, y+7, gate.name)

# --- Drag-and-Drop Gate Builder ---
class GatePalette(QtWidgets.QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window
        layout = QtWidgets.QHBoxLayout(self)
        self.setStyleSheet("background: #23272e; border-radius: 6px;")
        gate_icons = {
            "H": "🅷",  # Unicode for demo
            "X": "❌",
            "M": "📏"
        }
        for name, icon in gate_icons.items():
            btn = QtWidgets.QPushButton(icon)
            btn.setToolTip(f"Add {name} gate")
            btn.setFixedSize(40, 40)
            btn.setStyleSheet("background: #23272e; color: #b5cea8; font-size: 22px; border: 2px solid #007acc; border-radius: 20px;")
            btn.clicked.connect(lambda _, n=name: self.main_window.add_gate(n))
            layout.addWidget(btn)
        layout.addStretch()

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Qubo Quantum IDE")
        self.setStyleSheet("background-color: #181a1b; color: #d4d4d4;")
        self.resize(1300, 800)

        # Central widget layout
        central = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(central)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(0)

        # Sidebar
        self.sidebar = Sidebar(central)
        layout.addWidget(self.sidebar)

        # Main vertical layout (editor, circuit, output)
        main_vbox = QtWidgets.QVBoxLayout()
        main_vbox.setContentsMargins(8,8,8,8)
        main_vbox.setSpacing(8)

        # Window controls (macOS style)
        self.window_controls = WindowControls(self)
        main_vbox.addWidget(self.window_controls, alignment=QtCore.Qt.AlignRight)

        # Tabbed panel for sidebar
        self.tab_widget = QtWidgets.QStackedWidget()

        # --- Circuit Builder Panel ---
        builder_panel = QtWidgets.QWidget()
        builder_layout = QtWidgets.QVBoxLayout(builder_panel)
        self.gate_palette = GatePalette(self, self)
        builder_layout.addWidget(self.gate_palette)
        self.circuit_diagram = CircuitDiagram(self)
        builder_layout.addWidget(self.circuit_diagram)
        splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        self.editor = CodeEditor()
        self.editor.setPlainText("""# Write your quantum circuit code here\nfrom qubo.circuit import QuantumCircuit\nfrom qubo.gates import H, X, Measure\n\nqc = QuantumCircuit(2)\nqc.add_gate(H(0))\nqc.add_gate(X(1))\nqc.add_gate(Measure(0))\n""")
        splitter.addWidget(self.editor)
        self.output = OutputPanel()
        splitter.addWidget(self.output)
        splitter.setSizes([400, 200])
        builder_layout.addWidget(splitter)
        self.tab_widget.addWidget(builder_panel)

        # --- Simulator Panel ---
        self.simulator_panel = QtWidgets.QWidget()
        sim_layout = QtWidgets.QVBoxLayout(self.simulator_panel)
        self.sim_output = OutputPanel()
        sim_layout.addWidget(QtWidgets.QLabel("Simulator Results:"))
        sim_layout.addWidget(self.sim_output)
        self.tab_widget.addWidget(self.simulator_panel)

        # --- Visualizer Panel ---
        self.visualizer_panel = QtWidgets.QWidget()
        vis_layout = QtWidgets.QVBoxLayout(self.visualizer_panel)
        self.vis_diagram = CircuitDiagram(self)
        vis_layout.addWidget(QtWidgets.QLabel("Circuit Visualizer:"))
        vis_layout.addWidget(self.vis_diagram)
        self.vis_output = OutputPanel()
        vis_layout.addWidget(self.vis_output)
        self.tab_widget.addWidget(self.visualizer_panel)

        # --- Noise Panel ---
        self.noise_panel = QtWidgets.QWidget()
        noise_layout = QtWidgets.QVBoxLayout(self.noise_panel)
        noise_layout.addWidget(QtWidgets.QLabel("Noise Controls:"))
        self.noise_select = QtWidgets.QComboBox()
        self.noise_select.addItems(["None", "Bit-flip", "Phase-flip", "Depolarizing", "Amplitude Damping"])
        noise_layout.addWidget(self.noise_select)
        self.noise_output = OutputPanel()
        noise_layout.addWidget(self.noise_output)
        self.tab_widget.addWidget(self.noise_panel)

        # --- Docs Panel ---
        self.docs_panel = QtWidgets.QWidget()
        docs_layout = QtWidgets.QVBoxLayout(self.docs_panel)
        docs_layout.addWidget(QtWidgets.QLabel("Documentation and Quickstart coming soon!"))
        self.tab_widget.addWidget(self.docs_panel)

        main_vbox.addWidget(self.tab_widget)
        layout.addLayout(main_vbox)
        self.setCentralWidget(central)

        # Sidebar tab switching
        self.sidebar.currentRowChanged.connect(self.tab_widget.setCurrentIndex)
        self.sidebar.currentRowChanged.connect(self.on_tab_changed)

        # Menu bar
        menubar = self.menuBar()
        fileMenu = menubar.addMenu("File")
        openAction = QtWidgets.QAction("Open...", self)
        openAction.triggered.connect(self.open_file)
        saveAction = QtWidgets.QAction("Save As...", self)
        saveAction.triggered.connect(self.save_file)
        fileMenu.addAction(openAction)
        fileMenu.addAction(saveAction)
        runMenu = menubar.addMenu("Run")
        runAction = QtWidgets.QAction("Run Circuit", self)
        runAction.setShortcut("F5")
        runAction.triggered.connect(self.run_circuit)
        runMenu.addAction(runAction)

        # Internal circuit for builder
        self.builder_circuit = QuantumCircuit(2)
        self.update_circuit_diagram()

    def on_tab_changed(self, idx):
        # When switching tabs, update content if needed
        if idx == 1:  # Simulator
            self.run_simulator_panel()
        elif idx == 2:  # Visualizer
            self.update_visualizer_panel()
        elif idx == 3:  # Noise
            self.update_noise_panel()

    def run_simulator_panel(self):
        # Run the circuit and show results in Simulator panel
        code = self.editor.toPlainText()
        import io, contextlib, sys, traceback
        if '' not in sys.path:
            sys.path.insert(0, '')
        local_ns = {}
        f = io.StringIO()
        try:
            with contextlib.redirect_stdout(f):
                exec(code, {}, local_ns)
                if 'qc' in local_ns:
                    from qubo.simulator import StatevectorSimulator
                    sim = StatevectorSimulator(local_ns['qc'])
                    result = sim.run(shots=1000)
                    print(result)
                else:
                    print("No 'qc' QuantumCircuit found in code.")
        except Exception:
            f.write(traceback.format_exc())
        self.sim_output.setPlainText(f.getvalue())

    def update_visualizer_panel(self):
        # Show the circuit diagram and statevector bar chart
        code = self.editor.toPlainText()
        import io, contextlib, sys, traceback
        if '' not in sys.path:
            sys.path.insert(0, '')
        local_ns = {}
        f = io.StringIO()
        try:
            with contextlib.redirect_stdout(f):
                exec(code, {}, local_ns)
                if 'qc' in local_ns:
                    self.vis_diagram.set_circuit(local_ns['qc'])
                    from qubo.simulator import StatevectorSimulator
                    sim = StatevectorSimulator(local_ns['qc'])
                    sim.run(shots=1)
                    from qubo.visualizer import plot_statevector
                    import matplotlib.pyplot as plt
                    plot_statevector(sim.state)
                    plt.show()
                    print("Statevector visualized above.")
                else:
                    print("No 'qc' QuantumCircuit found in code.")
        except Exception:
            f.write(traceback.format_exc())
        self.vis_output.setPlainText(f.getvalue())

    def update_noise_panel(self):
        # Apply selected noise to the circuit and show result
        code = self.editor.toPlainText()
        noise_type = self.noise_select.currentText()
        import io, contextlib, sys, traceback
        if '' not in sys.path:
            sys.path.insert(0, '')
        local_ns = {}
        f = io.StringIO()
        try:
            with contextlib.redirect_stdout(f):
                exec(code, {}, local_ns)
                if 'qc' in local_ns:
                    from qubo.simulator import StatevectorSimulator
                    from qubo import noise
                    sim = StatevectorSimulator(local_ns['qc'])
                    state = sim.state
                    if noise_type == "Bit-flip":
                        state = noise.bit_flip(state, 0.1, 0)
                    elif noise_type == "Phase-flip":
                        state = noise.phase_flip(state, 0.1, 0)
                    elif noise_type == "Depolarizing":
                        state = noise.depolarizing(state, 0.1, 0)
                    elif noise_type == "Amplitude Damping":
                        state = noise.amplitude_damping(state, 0.1, 0)
                    print("Noisy state (first 8 amplitudes):", state[:8])
                else:
                    print("No 'qc' QuantumCircuit found in code.")
        except Exception:
            f.write(traceback.format_exc())
        self.noise_output.setPlainText(f.getvalue())
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Qubo Quantum IDE")
        self.setStyleSheet("background-color: #181a1b; color: #d4d4d4;")
        self.resize(1300, 800)

        # Central widget layout
        central = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(central)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(0)

        # Sidebar
        self.sidebar = Sidebar(central)
        layout.addWidget(self.sidebar)


    # Main vertical layout (editor, circuit, output)
    main_vbox = QtWidgets.QVBoxLayout()
    main_vbox.setContentsMargins(8,8,8,8)
    main_vbox.setSpacing(8)

    # Window controls (macOS style)
    self.window_controls = WindowControls(self)
    main_vbox.addWidget(self.window_controls, alignment=QtCore.Qt.AlignRight)

    # Tabbed panel for sidebar
    self.tab_widget = QtWidgets.QStackedWidget()

    # --- Circuit Builder Panel ---
    builder_panel = QtWidgets.QWidget()
    builder_layout = QtWidgets.QVBoxLayout(builder_panel)
    self.gate_palette = GatePalette(self, self)
    builder_layout.addWidget(self.gate_palette)
    self.circuit_diagram = CircuitDiagram(self)
    builder_layout.addWidget(self.circuit_diagram)
    splitter = QtWidgets.QSplitter(QtCore.Qt.Vertical)
    self.editor = CodeEditor()
    self.editor.setPlainText("""# Write your quantum circuit code here\nfrom qubo.circuit import QuantumCircuit\nfrom qubo.gates import H, X, Measure\n\nqc = QuantumCircuit(2)\nqc.add_gate(H(0))\nqc.add_gate(X(1))\nqc.add_gate(Measure(0))\n""")
    splitter.addWidget(self.editor)
    self.output = OutputPanel()
    splitter.addWidget(self.output)
    splitter.setSizes([400, 200])
    builder_layout.addWidget(splitter)
    self.tab_widget.addWidget(builder_panel)

    # --- Simulator Panel ---
    self.simulator_panel = QtWidgets.QWidget()
    sim_layout = QtWidgets.QVBoxLayout(self.simulator_panel)
    self.sim_output = OutputPanel()
    sim_layout.addWidget(QtWidgets.QLabel("Simulator Results:"))
    sim_layout.addWidget(self.sim_output)
    self.tab_widget.addWidget(self.simulator_panel)

    # --- Visualizer Panel ---
    self.visualizer_panel = QtWidgets.QWidget()
    vis_layout = QtWidgets.QVBoxLayout(self.visualizer_panel)
    self.vis_diagram = CircuitDiagram(self)
    vis_layout.addWidget(QtWidgets.QLabel("Circuit Visualizer:"))
    vis_layout.addWidget(self.vis_diagram)
    self.vis_output = OutputPanel()
    vis_layout.addWidget(self.vis_output)
    self.tab_widget.addWidget(self.visualizer_panel)

    # --- Noise Panel ---
    self.noise_panel = QtWidgets.QWidget()
    noise_layout = QtWidgets.QVBoxLayout(self.noise_panel)
    noise_layout.addWidget(QtWidgets.QLabel("Noise Controls:"))
    self.noise_select = QtWidgets.QComboBox()
    self.noise_select.addItems(["None", "Bit-flip", "Phase-flip", "Depolarizing", "Amplitude Damping"])
    noise_layout.addWidget(self.noise_select)
    self.noise_output = OutputPanel()
    noise_layout.addWidget(self.noise_output)
    self.tab_widget.addWidget(self.noise_panel)

    # --- Docs Panel ---
    self.docs_panel = QtWidgets.QWidget()
    docs_layout = QtWidgets.QVBoxLayout(self.docs_panel)
    docs_layout.addWidget(QtWidgets.QLabel("Documentation and Quickstart coming soon!"))
    self.tab_widget.addWidget(self.docs_panel)

    main_vbox.addWidget(self.tab_widget)
    layout.addLayout(main_vbox)
    self.setCentralWidget(central)

    # Sidebar tab switching
    self.sidebar.currentRowChanged.connect(self.tab_widget.setCurrentIndex)

    # Menu bar
    menubar = self.menuBar()
    fileMenu = menubar.addMenu("File")
    openAction = QtWidgets.QAction("Open...", self)
    openAction.triggered.connect(self.open_file)
    saveAction = QtWidgets.QAction("Save As...", self)
    saveAction.triggered.connect(self.save_file)
    fileMenu.addAction(openAction)
    fileMenu.addAction(saveAction)
    runMenu = menubar.addMenu("Run")
    runAction = QtWidgets.QAction("Run Circuit", self)
    runAction.setShortcut("F5")
    runAction.triggered.connect(self.run_circuit)
    runMenu.addAction(runAction)

    # Internal circuit for builder
    self.builder_circuit = QuantumCircuit(2)
    self.update_circuit_diagram()

    def add_gate(self, name):
        # Add gate to builder circuit and update code/circuit diagram
        if name == "H":
            self.builder_circuit.add_gate(H(0))
        elif name == "X":
            self.builder_circuit.add_gate(X(1))
        elif name == "M":
            self.builder_circuit.add_gate(Measure(0))
        self.update_circuit_diagram()
        # Sync code editor with builder circuit
        code = "from qubo.circuit import QuantumCircuit\nfrom qubo.gates import H, X, Measure\n\nqc = QuantumCircuit(2)\n"
        for g in self.builder_circuit.gates:
            if g.name == "H":
                code += "qc.add_gate(H(0))\n"
            elif g.name == "X":
                code += "qc.add_gate(X(1))\n"
            elif g.name == "M":
                code += "qc.add_gate(Measure(0))\n"
        self.editor.setPlainText(code)

    def update_circuit_diagram(self):
        self.circuit_diagram.set_circuit(self.builder_circuit)

    def open_file(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open Python File", "", "Python Files (*.py)")
        if path:
            with open(path, 'r', encoding='utf-8') as f:
                self.editor.setPlainText(f.read())
            self.output.setPlainText(f"Opened: {path}")

    def save_file(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save Python File", "", "Python Files (*.py)")
        if path:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(self.editor.toPlainText())
            self.output.setPlainText(f"Saved: {path}")

    def run_circuit(self):
        code = self.editor.toPlainText()
        import io
        import contextlib
        import sys
        import traceback
        if '' not in sys.path:
            sys.path.insert(0, '')
        local_ns = {}
        f = io.StringIO()
        try:
            with contextlib.redirect_stdout(f):
                exec(code, {}, local_ns)
                if 'qc' in local_ns:
                    from qubo.simulator import StatevectorSimulator
                    sim = StatevectorSimulator(local_ns['qc'])
                    result = sim.run(shots=1000)
                    print(result)
                    # Show statevector bar chart if available
                    try:
                        from qubo.visualizer import plot_statevector
                        import matplotlib.pyplot as plt
                        plot_statevector(sim.state)
                        plt.show()
                    except Exception:
                        pass
                else:
                    print("No 'qc' QuantumCircuit found in code.")
        except Exception:
            f.write(traceback.format_exc())
        self.output.setPlainText(f.getvalue())

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
