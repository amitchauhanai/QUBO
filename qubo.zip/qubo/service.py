from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
import importlib
import subprocess
import sys
from typing import List

from qubo.exec_helper import run_code_subprocess

app = FastAPI(title='qubo API')
# serve static web UI from html/ directory if present
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
import os

static_dir = os.path.join(os.path.dirname(__file__), '..', 'html')
static_dir = os.path.abspath(static_dir)
if os.path.isdir(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get('/')
def root():
    index_path = os.path.join(static_dir, 'index.html')
    if os.path.exists(index_path):
        return HTMLResponse(open(index_path, 'r', encoding='utf-8').read())
    return {'status': 'qubo API', 'docs': '/docs'}


class RunRequest(BaseModel):
    code: str
    shots: int = 1024


@app.post('/run')
def run_code(req: RunRequest):
    # use subprocess runner to avoid executing user code in process
    ok, res = run_code_subprocess(req.code, shots=req.shots)
    return {'ok': ok, 'result': res}


@app.get('/status')
def status():
    """Return availability of optional backends and components."""
    def check_module(name: str):
        try:
            importlib.import_module(name)
            return True
        except Exception:
            return False

    # jax availability by checking the adapter
    jax_ok = False
    try:
        jb = importlib.import_module('qubo.backends.jax_backend')
        jax_ok = getattr(jb, 'is_available', lambda: False)()
    except Exception:
        jax_ok = False

    return {
        'jax_backend': jax_ok,
        'density_backend': check_module('qubo.density'),
        'fastapi_installed': check_module('fastapi'),
        'opt_einsum': check_module('opt_einsum'),
    }


@app.get('/install-help')
def install_help(tool: str):
    """Return suggested pip commands for a named optional tool."""
    hints = {
        'jax': ['pip install jax jaxlib  # follow jax docs for CUDA wheels'],
        'fastapi': ['pip install fastapi uvicorn'],
        'tensor': ['pip install opt_einsum cotengra'],
    }
    return {'tool': tool, 'suggestions': hints.get(tool, ['# no suggestions available'])}


@app.post('/install')
def install(tool: str):
    """Attempt to install a tool via pip using the running Python executable.

    WARNING: this runs pip in the server environment. Intended for local developer use only.
    """
    mapping = {
        'jax': ['jax', 'jaxlib'],
        'fastapi': ['fastapi', 'uvicorn'],
        'tensor': ['opt_einsum', 'cotengra'],
    }
    pkgs = mapping.get(tool)
    if not pkgs:
        raise HTTPException(status_code=400, detail='unknown tool')
    cmd = [sys.executable, '-m', 'pip', 'install'] + pkgs
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=300)
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=500, detail='install timed out')
    return {'returncode': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}


def serve(host: str = '127.0.0.1', port: int = 8000):
    uvicorn.run(app, host=host, port=port)


if __name__ == '__main__':
    serve()
